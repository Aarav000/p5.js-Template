var sample;

function setup() {
  createCanvas(400, 400);
  sample = createSprite(200, 200, 30, 30);
}

function draw() {
  background(220);
  drawSprites();
}